module Main where

import qualified Compiler.Program

main = Compiler.Program.main

